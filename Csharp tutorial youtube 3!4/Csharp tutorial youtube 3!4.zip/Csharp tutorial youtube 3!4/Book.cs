﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_tutorial_youtube_3_4
{
    class Book
    {
        public string title;
        public string author;
        public int pages;
    }
}
